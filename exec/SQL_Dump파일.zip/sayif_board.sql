-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `hit_count` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `is_remove` bit(1) DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `remove_at` datetime(6) DEFAULT NULL,
  `content` text,
  `file` varchar(255) DEFAULT NULL,
  `title` text,
  `type` enum('Free','Worry') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKsds8ox89wwf6aihinar49rmfy` (`member_id`),
  CONSTRAINT `FKsds8ox89wwf6aihinar49rmfy` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (17,29,_binary '\0',76,'2024-08-01 10:00:00.000000','2024-08-13 05:46:19.432143',NULL,'오늘 친구랑 영화 봤는데 정말 재미있었어요! 가끔 이렇게 쉬는 것도 중요한 것 같아요. 여러분은 요즘 어떤 영화 보셨나요?',NULL,'영화 추천 좀 해주세요!','Free'),(27,30,_binary '\0',77,'2024-08-02 11:00:00.000000','2024-08-13 05:46:29.391361',NULL,'요즘 날씨가 너무 덥네요. 다들 건강 조심하세요! 여름에 시원하게 보낼 수 있는 꿀팁 있으시면 공유해 주세요!',NULL,'여름 나기 꿀팁!','Free'),(34,31,_binary '\0',78,'2024-08-03 12:00:00.000000','2024-08-13 05:46:32.898411',NULL,'얼마 전에 취업 준비 시작했는데 생각보다 어려운 것 같아요. 자소서도 어렵고 면접도 부담스럽네요. 다들 어떻게 준비하고 계신가요?',NULL,'취업 준비 너무 힘들어요...','Worry'),(18,32,_binary '\0',79,'2024-08-04 13:00:00.000000','2024-08-04 13:00:00.000000',NULL,'최근에 아르바이트를 시작했는데, 생각보다 체력적으로 힘드네요. 그래도 경험을 쌓는다고 생각하고 열심히 해보려고요. 여러분은 어떤 일 하고 계신가요?',NULL,'첫 알바 시작했어요!','Free'),(22,33,_binary '\0',80,'2024-08-05 14:00:00.000000','2024-08-05 14:00:00.000000',NULL,'내일 중요한 면접이 있는데, 너무 긴장돼요. 면접장에서 실수하지 않을까 걱정이 되네요. 면접 잘 보는 방법 있으면 조언 부탁드려요.',NULL,'면접 전날인데 너무 떨려요','Worry'),(10,34,_binary '\0',81,'2024-08-06 15:00:00.000000','2024-08-06 15:00:00.000000',NULL,'주말에 가까운 곳으로 혼자 여행 다녀왔어요. 혼자만의 시간도 정말 중요하다는 걸 다시 느꼈습니다. 여러분도 가끔은 혼자만의 시간을 가져보세요.',NULL,'혼자 여행 다녀왔어요','Free'),(9,35,_binary '\0',82,'2024-08-07 16:00:00.000000','2024-08-13 07:44:24.491329',NULL,'요즘 일과 생활의 균형을 맞추는 게 정말 어려워요. 퇴근 후에는 완전히 쉬고 싶은데, 자꾸 일 생각이 나서 스트레스 받아요.',NULL,'일과 생활의 균형 맞추기 어렵네요','Worry'),(19,36,_binary '\0',83,'2024-08-08 17:00:00.000000','2024-08-15 08:16:23.722791',NULL,'이번 주말에 친구들이랑 캠핑 가기로 했어요! 자연 속에서 힐링하고 오려고요. 다들 주말 잘 보내세요!',NULL,'주말 캠핑 계획 중이에요','Free'),(41,37,_binary '\0',84,'2024-08-09 18:00:00.000000','2024-08-15 07:47:47.952442',NULL,'사회생활을 하면서 사람들과의 관계가 가장 어려운 것 같아요. 어떻게 해야 좋은 관계를 유지할 수 있을지 고민이 많네요.',NULL,'직장 내 인간관계가 어려워요','Worry'),(23,38,_binary '\0',85,'2024-08-10 19:00:00.000000','2024-08-15 08:16:11.731504',NULL,'집에서 요리하는 걸 좋아해서, 오늘은 파스타를 만들어봤어요. 처음엔 서툴렀지만 점점 나아지고 있는 것 같아요. 여러분은 어떤 요리 좋아하시나요?',NULL,'오늘은 파스타를 만들어봤어요','Free'),(23,49,_binary '\0',86,'2024-07-11 10:00:00.000000','2024-08-14 00:27:12.708238',NULL,'최근에 독서에 빠졌어요. 시간 날 때마다 책을 읽으면서 지식을 쌓는 게 너무 즐거워요. 여러분은 어떤 책을 읽고 계신가요?',NULL,'요즘 읽고 있는 책은?','Free'),(18,50,_binary '\0',87,'2024-07-12 11:00:00.000000','2024-07-12 11:00:00.000000',NULL,'매일 아침 조깅을 시작했어요. 몸도 마음도 건강해지는 느낌이 들어요. 아침에 운동하는 습관 추천드립니다!',NULL,'아침 운동의 장점','Free'),(22,51,_binary '\0',88,'2024-07-12 12:00:00.000000','2024-07-13 12:00:00.000000',NULL,'취업 면접에서 자꾸 떨어지니 자존감이 많이 낮아졌어요. 자신감을 되찾고 싶은데 어떻게 해야 할지 모르겠어요.',NULL,'자신감 회복이 필요해요','Worry'),(16,52,_binary '\0',89,'2024-07-14 13:00:00.000000','2024-07-14 13:00:00.000000',NULL,'자립 준비를 하면서 가장 어려운 게 금전 관리인 것 같아요. 예산을 짜도 항상 예상치 못한 지출이 생겨서 고민이 많아요.',NULL,'금전 관리가 너무 어려워요','Worry'),(14,53,_binary '\0',90,'2024-07-15 14:00:00.000000','2024-07-15 14:00:00.000000',NULL,'요즘 새로운 취미로 사진 촬영을 시작했어요. 주변의 작은 것들도 다르게 보이는 것 같아요. 사진 찍는 재미에 푹 빠졌습니다.',NULL,'사진 찍는 재미!','Free'),(19,54,_binary '\0',91,'2024-07-16 15:00:00.000000','2024-07-16 15:00:00.000000',NULL,'다들 건강 관리 잘 하고 계신가요? 저는 최근에 건강 검진을 받고 나서 운동을 시작했어요. 건강은 정말 중요한 것 같아요.',NULL,'건강 관리의 중요성','Free'),(12,55,_binary '\0',76,'2024-07-17 16:00:00.000000','2024-07-17 16:00:00.000000',NULL,'회사에서 실수해서 상사에게 혼났어요. 앞으로 어떻게 더 잘할 수 있을지 고민이 됩니다. 실수 없이 일하는 법이 있을까요?',NULL,'회사에서 실수를 했어요...','Worry'),(22,56,_binary '\0',77,'2024-07-18 17:00:00.000000','2024-08-13 07:44:00.493648',NULL,'주말에 친구들과 함께 요리 모임을 했어요. 함께 요리하고 먹는 시간이 정말 즐거웠어요. 다들 어떤 요리를 좋아하시나요?',NULL,'요리 모임의 즐거움','Free'),(24,57,_binary '\0',78,'2024-07-19 18:00:00.000000','2024-07-19 18:00:00.000000',NULL,'친구가 최근에 취업해서 저만 뒤처지는 느낌이 들어요. 다들 취업 준비 어떻게 하고 계신가요? 저도 빨리 좋은 소식을 전하고 싶네요.',NULL,'친구들만 취업해서 뒤처진 기분이에요','Worry'),(23,58,_binary '\0',79,'2024-07-20 19:00:00.000000','2024-07-20 19:00:00.000000',NULL,'요즘 새로운 운동으로 요가를 시작했어요. 몸이 유연해지는 것 같고 마음도 편안해져서 너무 좋아요. 요가 강추합니다!',NULL,'요가 시작했어요!','Free');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:02
