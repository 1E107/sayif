-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `challenge`
--

DROP TABLE IF EXISTS `challenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenge` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `status` enum('Before','Process','Success') DEFAULT NULL,
  `challenge_num` int DEFAULT NULL,
  `team_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK208tyghvx3qmc56eph4332gds` (`challenge_num`),
  KEY `FKk4h1ia2cxxl2bksfomnrvxex0` (`team_id`),
  CONSTRAINT `FK208tyghvx3qmc56eph4332gds` FOREIGN KEY (`challenge_num`) REFERENCES `challenge_list` (`id`),
  CONSTRAINT `FKk4h1ia2cxxl2bksfomnrvxex0` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge`
--

LOCK TABLES `challenge` WRITE;
/*!40000 ALTER TABLE `challenge` DISABLE KEYS */;
INSERT INTO `challenge` VALUES (127,'Before',1,25),(128,'Before',2,25),(129,'Before',3,25),(130,'Before',4,25),(131,'Before',5,25),(132,'Before',6,25),(133,'Before',7,25),(134,'Before',1,26),(135,'Before',2,26),(136,'Before',3,26),(137,'Before',4,26),(138,'Before',5,26),(139,'Before',6,26),(140,'Before',7,26),(141,'Before',1,27),(142,'Before',2,27),(143,'Before',3,27),(144,'Before',4,27),(145,'Before',5,27),(146,'Before',6,27),(147,'Before',7,27),(148,'Before',1,28),(149,'Before',2,28),(150,'Before',3,28),(151,'Before',4,28),(152,'Before',5,28),(153,'Before',6,28),(154,'Before',7,28),(155,'Before',1,29),(156,'Before',2,29),(157,'Before',3,29),(158,'Before',4,29),(159,'Before',5,29),(160,'Before',6,29),(161,'Before',7,29),(162,'Success',1,30),(163,'Before',2,30),(164,'Process',3,30),(165,'Success',4,30),(166,'Before',5,30),(167,'Before',6,30),(168,'Success',7,30),(169,'Before',1,31),(170,'Before',2,31),(171,'Before',3,31),(172,'Before',4,31),(173,'Before',5,31),(174,'Before',6,31),(175,'Before',7,31);
/*!40000 ALTER TABLE `challenge` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:10
