-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `team_id` int DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `profile_img` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `role` enum('Admin','Mentee','Mentor') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKcjte2jn9pvo9ud2hyfgwcja0k` (`team_id`),
  CONSTRAINT `FKcjte2jn9pvo9ud2hyfgwcja0k` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (72,NULL,'kang@bongnsul.com','M','박강빈','강빈공원','$2a$10$mQQlSnY5xM2m4LOIAc/FPOo6TMQPaw7bty2BmvRop8T3OXt9hM42K','010-2314-0648','https://sayif.s3.ap-northeast-2.amazonaws.com/default.jpg','bogusboy','Mentee'),(76,28,'sora1@ssafy.com','F','권정솔','소라','$2a$10$fe2GR4W9q1/3co1dKKW8Xux25.nWbXOxbR1o75I3CKfDUzF31z5S2','010-7531-3028','https://sayif.s3.ap-northeast-2.amazonaws.com/2e4b266a-cc4f-4512-8f34-c91c2760f746_cat%2B%25281%2529.jpg','sora1','Mentor'),(77,25,'qkdgur0323@gmail.com','M','방혁','파이리','$2a$10$NOQMpmimm1rj8VGzB66Vkugauzhr5MtsCcO93Fu9z12bdznBu8USO','010-8539-9905','https://sayif.s3.ap-northeast-2.amazonaws.com/68bdb05e-c719-4a7d-83fc-35109f31888d_%25ED%258C%258C%25EC%259D%25B4%25EB%25A6%25AC2.jpg','bang1','Mentor'),(78,30,'hello.ss1525@gmail.com','F','이승지','매루','$2a$10$cVM0IfxLIGZbm8brw6.vr.UjteMQ83/A23v0MJJW2jJ2qhWt4n4.W','010-9947-7247','https://sayif.s3.ap-northeast-2.amazonaws.com/fd2a9ccd-7d60-4b88-8026-f65ac93d5532_c8b29dac77ea9bca9b96583f8ed3a8957f9f127ae3ca5dc7f0f6349aebcdb3c4.png','meru1','Mentor'),(79,25,'qkrdusgn00@naver.com','M','박연후','북극곰','$2a$10$Yzy63ou0Ui3PdSFW2H92aOsQAQfyUQYsjSkOv/.xEweOIWB81UIc2','010-3844-6566','https://sayif.s3.ap-northeast-2.amazonaws.com/cc4854b4-be93-4fa9-a029-6b0dd0ba50d6_images%2B%25281%2529.jpg','cut1','Mentor'),(80,28,'ckdgh6589@naver.com','M','이창호','고둥','$2a$10$OnHlfwaL6jYJtWlU4B6Q7.hPMIaaRR4ngbIKqhpI3UXmR/4XNA0Um','010-9998-6589','https://sayif.s3.ap-northeast-2.amazonaws.com/01235b6d-4ded-49a2-af49-838a11cc412e_%25EA%25B3%25A0%25EB%258F%2599.jpg','godoong1','Mentor'),(81,30,'sora2@ssafy.com','F','권정솔','케로피','$2a$10$lezsLCtS.a8JbDE1td0wduv/j4rC5XlXwfxygjEwNKMHow15VvVbq','010-7531-3028','https://sayif.s3.ap-northeast-2.amazonaws.com/62155b5d-7da5-4e31-954d-a0401f366cd1_%25EC%25BC%2580%25EB%25A1%259C%25ED%2594%25BC.png','sora2','Mentor'),(82,26,'qkrdusgn00@naver.com','M','박연후','푸바오','$2a$10$YXtORYEOOxqyNlT/Q.W/0uFepr0Pg7WH38yNZsA1xi/ZpCe5T5k3a','010-3844-6566','https://sayif.s3.ap-northeast-2.amazonaws.com/9317bdd1-6737-4b3f-817e-133c61117ea1_%25EB%258B%25A4%25EC%259A%25B4%25EB%25A1%259C%25EB%2593%259C%2B%25281%2529.jpg','cut2','Mentor'),(83,29,'happy.ss1525@gmail.com','F','이승지','코딩강쥐','$2a$10$MBJJM2Eetg10olQgBphgI.LWuR6uphpQjjlh.Qpe./qqWkGwHsS.K','010-9947-7247','https://sayif.s3.ap-northeast-2.amazonaws.com/451bf84e-d9bd-4772-af8f-dbdba71c0026_%25EB%258B%25A4%25EC%259A%25B4%25EB%25A1%259C%25EB%2593%259C.jfif','meru2','Mentor'),(84,27,'bhe0323@naver.com','M','방혁','이브이','$2a$10$dNFSDsUm/Tss8NWf9C.GwegGixQopOblw6iHZi6iH0Fzdh9rEu23m','010-8539-9905','https://sayif.s3.ap-northeast-2.amazonaws.com/49aff0d9-f33f-4902-83b7-feec5b6ccafc_%25EC%259D%25B4%25EB%25B8%258C%25EC%259D%25B4.jpg','bang2','Mentor'),(85,26,'ssafy@ssafy.com','F','배선영','오복','$2a$10$7Fam.F3PqEPRdeayQ0/Xaudkmj5MyK7oORmBfrmD8ru3MuxHvNSiy','010-9947-7247','https://sayif.s3.ap-northeast-2.amazonaws.com/bc359e41-ad09-4fa8-976a-4525048c0fa7_2001162_41524_357.jpg','ohbok1','Mentor'),(86,29,'ssafy@ssafy.com','F','배선영','코딩애플','$2a$10$GjxnELlMiuxTq3SaWe88zu1ZoOBPqejpM49lialK16uTHfL1mIeCW','010-9947-7247','https://sayif.s3.ap-northeast-2.amazonaws.com/e0e9fb8d-b366-4285-aa5a-15b6790c0aa3_images.jfif','ohbok2','Mentor'),(87,27,'ckdgh6589@naver.com','M','이창호','꼬부기','$2a$10$/blY6wHu42wfrNYbkkseLOZDaA5OYL2NLLG6iDWV3loeOFvJ0lIJq','010-9998-6589','https://sayif.s3.ap-northeast-2.amazonaws.com/d50ec5c3-4d7d-48c1-a6e5-103895a71a33_%25EA%25BC%25AC%25EB%25B6%2580%25EA%25B8%25B0%25EC%2582%25AC%25EC%25A7%2584.jpg','godoong2','Mentor'),(88,30,'qkrdusgn00@naver.com','M','비혁','뽀로로','$2a$10$vdTv5.i91C3yj.cLsrbEJe6COH4GcxeqcMZNevDwABcmTuEnhUFUK','010-3844-6566','https://sayif.s3.ap-northeast-2.amazonaws.com/0e6a2471-c9db-4bd4-93b5-d09a6de02d0e_%25EB%258B%25A4%25EC%259A%25B4%25EB%25A1%259C%25EB%2593%259C%2B%25282%2529.jpg','mentee2','Mentee'),(89,30,'happy.ss1525@gmail.com','F','이순자','네잎클로버','$2a$10$hH20DnEGGLdXcAXUi/XNzu/O6oeZXNmxhBOUCmKJRkuxY4KqdpuPC','010-9947-7247','https://sayif.s3.ap-northeast-2.amazonaws.com/687da256-54c5-4fcc-9556-f66991cd17aa_2129348d06d68c2d4eec40f45e126e2e.jpg','mentee4','Mentee'),(90,30,'hgd@ssafy.com','F','건정설','한교동','$2a$10$TIVzUM8P/.JaBOJcJ8vzh.pOsdAM/Z2FUlzEbu4iuX6HLZLgiAcSS','010-7531-3028','https://sayif.s3.ap-northeast-2.amazonaws.com/c27b238f-3155-40d5-be50-7bb35d58592d_%25ED%2595%259C%25EA%25B5%2590%25EB%258F%2599.png','mentee1','Mentee'),(91,30,'qkdgur0323@gmail.com','M','박후연','포차코','$2a$10$p1Uw22EihTjJqBZaChyEweS.UwQI/LPHrvx9Aq/zKUogExxRNPsKa','010-8539-9905','https://sayif.s3.ap-northeast-2.amazonaws.com/4ca0e4cd-513f-4c64-bb6e-1f1710f1e18c_%25ED%258F%25AC%25EC%25B0%25A8%25EC%25BD%2594.png','mentee3','Mentee'),(92,NULL,'ssafy@ssfy.com','M','관리자','새잎','$2a$10$rI7/yqJNtghxS6cQXk38g.RBKDCuEe05MS.Z0nQPa0bpCFzEHAIXO','010-9947-7247','https://sayif.s3.ap-northeast-2.amazonaws.com/12cc7816-99cb-4223-978c-ba634d35fcec_logo.png','ssafy','Admin'),(93,31,'tjsdudqo1234@naver.com','F','배선영','냥냥이','$2a$10$0USY8CiPjA.AtE8DiPUC3O1kYnOSGnlZwYml4ahlTvDpM3.pf6Jbu','010-8541-1041','https://sayif.s3.ap-northeast-2.amazonaws.com/4bf96783-7cd1-41e8-b58f-f3d902be75c3_KakaoTalk_20240810_235817012.jpg','qotjsdud67','Mentor'),(94,NULL,'ssafy@ssafy.com','M','ssafy','ssafys','$2a$10$ybHVTYxDbC95manegL/GFu.0IyQbaeqOOkRYW1MAwboeGc7yzIXZ.','010-6617-4980','https://sayif.s3.ap-northeast-2.amazonaws.com/default.jpg','sssafy','Mentee'),(95,NULL,'ssafy@ssafy.com','M','임승진','c++마스터','$2a$10$5r7Tjfk/7gUYr3zbMBcwA.fyY5ccQH11xs45zZ1mscwL1xxL8k.r6','010-9947-7247','https://sayif.s3.ap-northeast-2.amazonaws.com/default.jpg','sj1234','Mentee'),(96,31,'ssafy@ssafy.com','M','임승진','자바마스터','$2a$10$AcdmCA2aGaUoMrVmmmBsFetOygKVkIMo4YeRim4FvAWMQxLW58cAq','010-9947-7247','https://sayif.s3.ap-northeast-2.amazonaws.com/default.jpg','sjsj12','Mentor'),(97,NULL,'ssafy@ssafy.com','M','홍길동','나도코딩','$2a$10$1fGX2e9IKHwkLcr7lgqqwO4JM.6YMRlV7d9kEHZQTxSzdK54uzUiq','010-9947-7247','https://sayif.s3.ap-northeast-2.amazonaws.com/default.jpg','nado123','Mentee');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:06
