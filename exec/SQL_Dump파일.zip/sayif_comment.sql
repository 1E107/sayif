-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `board_id` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  KEY `FKlij9oor1nav89jeat35s6kbp1` (`board_id`),
  KEY `FKmrrrpi513ssu63i2783jyiv9m` (`member_id`),
  CONSTRAINT `FKlij9oor1nav89jeat35s6kbp1` FOREIGN KEY (`board_id`) REFERENCES `board` (`id`),
  CONSTRAINT `FKmrrrpi513ssu63i2783jyiv9m` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (29,43,76,'2024-08-01 12:00:00.000000','2024-08-01 12:00:00.000000','저도 최근에 그 영화를 봤는데 정말 재미있었어요!'),(29,44,77,'2024-08-01 12:30:00.000000','2024-08-01 12:30:00.000000','영화 추천 감사합니다! 주말에 봐야겠네요.'),(30,45,78,'2024-08-02 13:00:00.000000','2024-08-02 13:00:00.000000','저는 선풍기를 항상 틀어놓고 있어요. 덕분에 조금 시원해요.'),(31,46,79,'2024-08-03 14:00:00.000000','2024-08-03 14:00:00.000000','취업 준비 정말 힘들죠. 저도 자소서 쓰는 게 너무 어려워요. 힘내세요!'),(32,47,80,'2024-08-04 15:00:00.000000','2024-08-04 15:00:00.000000','첫 알바라니! 많이 배우시고 좋은 경험 되시길 바랍니다.'),(33,48,81,'2024-08-05 16:00:00.000000','2024-08-05 16:00:00.000000','면접 전에 심호흡하고 마음을 가라앉히는 게 중요하다고 하더라고요. 잘 하실 거예요!'),(34,49,82,'2024-08-06 17:00:00.000000','2024-08-06 17:00:00.000000','혼자 여행 너무 좋죠! 저도 가끔 혼자만의 시간을 가져요.'),(35,50,83,'2024-08-07 18:00:00.000000','2024-08-07 18:00:00.000000','저도 워라밸 맞추기 어렵다고 느껴요. 퇴근 후에 일 생각 안 하려 노력 중이에요.'),(36,51,84,'2024-08-08 19:00:00.000000','2024-08-08 19:00:00.000000','캠핑이라니! 부러워요. 저도 자연 속에서 힐링하고 싶네요.'),(38,52,85,'2024-08-09 20:00:00.000000','2024-08-09 20:00:00.000000','요리 정말 멋져요! 다음엔 어떤 요리 도전하시나요?'),(49,53,86,'2024-07-11 13:00:00.000000','2024-07-11 13:00:00.000000','저도 그 책 읽었는데 정말 감동적이었어요.'),(50,54,87,'2024-07-12 14:00:00.000000','2024-07-12 14:00:00.000000','아침 운동이 정말 상쾌하죠. 저도 매일 하고 있어요.'),(51,55,88,'2024-07-13 15:00:00.000000','2024-07-13 15:00:00.000000','자신감을 잃지 마세요. 언젠가 꼭 좋은 소식 있을 거예요.'),(52,56,89,'2024-07-14 16:00:00.000000','2024-07-14 16:00:00.000000','저도 금전 관리 어려워요. 예산 짜는 방법을 더 공부해야겠어요.'),(53,57,90,'2024-07-15 17:00:00.000000','2024-07-15 17:00:00.000000','사진 촬영 정말 재밌죠. 저도 취미로 찍고 있어요!'),(54,58,91,'2024-07-16 18:00:00.000000','2024-07-16 18:00:00.000000','건강이 정말 중요한 것 같아요. 저도 최근에 운동 시작했어요.'),(55,59,76,'2024-07-17 19:00:00.000000','2024-07-17 19:00:00.000000','회사에서 실수는 누구나 할 수 있어요. 너무 자책하지 마세요.'),(56,60,77,'2024-07-18 20:00:00.000000','2024-07-18 20:00:00.000000','요리 모임이라니! 정말 즐거운 시간이었을 것 같아요.'),(57,61,78,'2024-07-19 21:00:00.000000','2024-07-19 21:00:00.000000','저도 그 기분 알아요. 힘내세요, 분명히 잘 될 거예요.'),(58,62,79,'2024-07-20 22:00:00.000000','2024-07-20 22:00:00.000000','요가 시작하셨다니 멋져요! 저도 한 번 해볼까 봐요.'),(36,63,89,'2024-08-13 07:44:15.717534','2024-08-13 07:44:15.717534','캠핑 저도 참 좋아하는데! 부럽네요');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:10
