-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team_board`
--

DROP TABLE IF EXISTS `team_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_board` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int DEFAULT NULL,
  `team_id` int DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKktblgfr2gcmegk5w5nibxrv7o` (`member_id`),
  KEY `FKq0xtsbia2ftfnpef7myltf3tt` (`team_id`),
  CONSTRAINT `FKktblgfr2gcmegk5w5nibxrv7o` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FKq0xtsbia2ftfnpef7myltf3tt` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_board`
--

LOCK TABLES `team_board` WRITE;
/*!40000 ALTER TABLE `team_board` DISABLE KEYS */;
INSERT INTO `team_board` VALUES (11,88,30,'2024-08-11 10:00:00.000000','2024-08-11 10:00:00.000000','최근에 코딩을 시작했는데, 자바스크립트와 파이썬 중 어떤 언어를 먼저 배우는 게 좋을지 고민이에요. 두 언어의 차이점과 장단점에 대해 알고 싶어요.','자바 vs 파이썬, 무엇을 먼저 배울까요?'),(12,89,30,'2024-08-12 11:00:00.000000','2024-08-12 11:00:00.000000','개발자로서의 진로를 선택하고 싶은데, 백엔드와 프론트엔드 중 어떤 분야가 저에게 더 맞을지 잘 모르겠어요. 두 분야의 차이점과 각각의 장단점에 대해 알고 싶어요.','백엔드와 프론트엔드, 어느 쪽이 더 맞을까요?'),(13,90,30,'2024-08-13 12:00:00.000000','2024-08-13 12:00:00.000000','코딩을 공부하다가 종종 버그를 마주하는데, 어떻게 하면 효율적으로 디버깅을 할 수 있을지 궁금합니다. 디버깅 팁이나 좋은 방법이 있다면 공유해주세요.','효율적인 디버깅 방법이 궁금해요'),(14,91,30,'2024-08-14 13:00:00.000000','2024-08-14 13:00:00.000000','앞으로 AI 분야로 진로를 정하고 싶은데, 어떤 언어와 기술을 우선적으로 공부해야 할지 고민입니다. AI 분야에서 필수적인 기술이 무엇인지 알고 싶어요.','AI 진로를 위한 필수 기술은 무엇인가요?'),(15,88,30,'2024-08-08 14:00:00.000000','2024-08-08 14:00:00.000000','최근 HTML과 CSS를 공부하기 시작했는데, 레이아웃 잡기가 너무 어렵네요. 반응형 웹 디자인을 쉽게 할 수 있는 방법이 있을까요?','반응형 웹 디자인 쉽게 할 수 있는 방법?'),(16,89,30,'2024-08-09 15:00:00.000000','2024-08-09 15:00:00.000000','데이터베이스 설계가 어렵다고 느껴지네요. 테이블 간의 관계를 어떻게 설정해야 하는지, 그리고 데이터 정규화가 무엇인지 이해가 잘 안 돼요.','데이터베이스 설계와 정규화가 궁금해요'),(17,90,30,'2024-08-10 16:00:00.000000','2024-08-10 16:00:00.000000','코딩 부트캠프를 수료한 후 취업 준비 중인데, 포트폴리오에 어떤 프로젝트를 포함시켜야 할지 고민이에요. 어떤 프로젝트가 면접관에게 인상적일까요?','포트폴리오는 어떻게 시작하나요?'),(18,91,30,'2024-08-11 17:00:00.000000','2024-08-11 17:00:00.000000','프로그래밍 언어를 독학 중인데, 깊이 있게 공부하는 방법을 알고 싶어요. 초보자로서 학습 효과를 극대화할 수 있는 방법이 있을까요?','프로그래밍 언어, 깊이 있게 공부하는 방법');
/*!40000 ALTER TABLE `team_board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:04
