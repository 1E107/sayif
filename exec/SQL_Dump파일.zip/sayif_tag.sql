-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `is_remove` bit(1) NOT NULL,
  `mentor_id` int DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKsiapwkuy7mksce974g864f5k6` (`mentor_id`),
  CONSTRAINT `FK4kwcvomqt30obfex433chwghj` FOREIGN KEY (`mentor_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FKsiapwkuy7mksce974g864f5k6` FOREIGN KEY (`mentor_id`) REFERENCES `mentor` (`mentor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (_binary '',82,88,'Java',NULL),(_binary '\0',82,89,'INTP',NULL),(_binary '',82,90,'Spring',NULL),(_binary '\0',77,91,'ESTJ',NULL),(_binary '\0',77,92,'떠거운',NULL),(_binary '\0',77,93,'부산',NULL),(_binary '',77,94,'따뜻함',NULL),(_binary '',77,95,'ESTJ',NULL),(_binary '',77,96,'떠거운',NULL),(_binary '',77,97,'부산',NULL),(_binary '',77,98,'따뜻함',NULL),(_binary '\0',84,99,'ENFP',NULL),(_binary '\0',84,100,'해피',NULL),(_binary '\0',84,101,'유쾌함',NULL),(_binary '\0',84,102,'친절',NULL),(_binary '\0',82,103,'Android',NULL),(_binary '\0',82,104,'Kotlin',NULL),(_binary '\0',77,105,'JAVA',NULL),(_binary '\0',82,106,'탕후루',NULL),(_binary '\0',78,107,'ISTP',NULL),(_binary '\0',78,108,'열정',NULL),(_binary '\0',78,109,'긍정',NULL),(_binary '\0',78,110,'친근',NULL),(_binary '',76,111,'ESTJ',NULL),(_binary '',76,112,'JAVA',NULL),(_binary '',76,113,'열정적',NULL),(_binary '',76,114,'고양이',NULL),(_binary '\0',76,115,'ESTJ',NULL),(_binary '\0',76,116,'JAVA',NULL),(_binary '\0',76,117,'열정적',NULL),(_binary '\0',76,118,'고양이',NULL),(_binary '',79,119,'차가워보이지만 따뜻한',NULL),(_binary '\0',79,120,'INFP',NULL),(_binary '\0',79,121,'Java',NULL),(_binary '\0',79,122,'React',NULL),(_binary '\0',83,123,'EEEE',NULL),(_binary '\0',83,124,'잘하면 짖는 강아지',NULL),(_binary '',83,125,'왈왈',NULL),(_binary '',83,126,'EEEE',NULL),(_binary '',83,127,'잘하면 짖는 강아지',NULL),(_binary '',83,128,'왈왈',NULL),(_binary '',83,129,'EEEE',NULL),(_binary '',83,130,'잘하면 짖는 강아지',NULL),(_binary '',83,131,'왈왈',NULL),(_binary '\0',83,132,'멍멍',NULL),(_binary '\0',79,133,'해치지 않아요',NULL),(_binary '\0',81,134,'INFP',NULL),(_binary '\0',81,135,'C++',NULL),(_binary '\0',81,136,'로봇이아닙니다',NULL),(_binary '\0',87,137,'ISTJ',NULL),(_binary '\0',87,138,'열정강사',NULL),(_binary '\0',80,139,'ESTP',NULL),(_binary '\0',80,140,'직관적',NULL),(_binary '\0',80,141,'따뜻함',NULL),(_binary '',80,142,'안녕',NULL),(_binary '\0',85,143,'INFJ',NULL),(_binary '\0',85,144,'열정',NULL),(_binary '\0',85,145,'불닭',NULL),(_binary '\0',86,146,'ENTJ',NULL),(_binary '\0',86,147,'상큼',NULL),(_binary '\0',86,148,'발랄',NULL),(_binary '\0',86,149,'프론트',NULL),(_binary '',93,150,'열정단비',NULL),(_binary '',93,151,'c++',NULL),(_binary '',93,152,'ISFP',NULL),(_binary '\0',93,153,'열정강사',NULL),(_binary '\0',93,154,'ISFP',NULL),(_binary '\0',93,155,'c++좋아',NULL);
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:04
