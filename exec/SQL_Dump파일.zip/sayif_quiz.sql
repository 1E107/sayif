-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz` (
  `chapter` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `question` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
INSERT INTO `quiz` VALUES (1,1,'운영체제에 대한 설명입니다. 올바른 것은 무엇일까요?'),(2,2,'정규화(Normalization)는 데이터베이스 설계에서 무엇을 목적으로 하나요?\n\n'),(3,3,'다음 중 조건문(Conditional Statement)에 해당하는 제어 구조는 무엇인가요?\n\n'),(4,4,'시간 복잡도가 O(n^2)인 알고리즘의 예로 자주 언급되는 정렬 알고리즘은 무엇인가요?\n\n'),(6,5,'다음 중 객체지향 프로그래밍(OOP)의 기본 개념이 아닌 것은 무엇인가요?\n\n'),(1,6,'프로세스에 대한 설명으로 올바른 것은?'),(2,7,'네트워크에 설명으로 올바른 것은 무엇일까요?'),(2,8,'TCP/IP 모델에서 \"인터넷 계층\"에 해당하는 프로토콜은 무엇인가요?'),(4,9,'다음 중 선형 자료구조가 아닌 것은 무엇인가요?'),(1,10,'CPU의 기본 구성 요소에 해당하지 않는 것은 무엇인가요?'),(6,11,'다음 중 파이썬(Python)에서 변수의 타입을 선언하지 않아도 되는 이유는 무엇인가요?'),(2,12,'IPv4 주소는 몇 비트로 구성되어 있나요?'),(4,13,'다음 중 재귀 호출(Recursive Call)로 구현할 수 없는 알고리즘은 무엇인가요?'),(2,14,'SQL에서 데이터베이스의 데이터를 조회하는 명령어는 무엇인가요?'),(1,15,'다음 중 운영체제의 주된 기능이 아닌 것은 무엇인가요?'),(6,16,'다음 중 객체지향 프로그래밍의 4대 특징에 속하지 않는 것은 무엇인가요?'),(2,17,'HTTP 프로토콜에서 상태 코드 404는 무엇을 의미하나요?'),(7,18,'ChatGPT는 어떤 방식으로 학습되었나요?'),(7,19,'ChatGPT의 가장 큰 특징 중 하나는 무엇인가요?'),(7,20,'ChatGPT는 사용자가 물어보는 모든 질문에 대해 정확한 답변을 보장할 수 있나요?'),(8,21,'다음 중 컴퓨터 네트워크에서 TCP와 UDP의 주요 차이점은 무엇인가요?'),(8,22,'다음 중 메모리 관리 기법 중 \"페이징(paging)\"의 주요 특징은 무엇인가요?'),(8,23,'파이썬에서 함수의 기본 인자로 사용된 리스트가 함수 호출 시마다 초기화되지 않고, 이전 호출의 결과를 유지하는 이유는 무엇인가요?'),(5,24,'다음 중 CSS를 사용하여 HTML 요소의 배치를 제어하는 방법으로 가장 적절한 것은 무엇인가요?'),(3,25,'블록코딩의 주요 장점 중 하나는 무엇인가요?'),(3,26,'다음 중 블록코딩을 주로 사용하는 대상은 누구인가요?'),(3,27,'블록코딩에서 조건문(If-Else) 블록의 역할은 무엇인가요?');
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:03
