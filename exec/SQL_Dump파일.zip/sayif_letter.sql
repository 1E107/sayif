-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `letter`
--

DROP TABLE IF EXISTS `letter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `letter` (
  `id` int NOT NULL AUTO_INCREMENT,
  `receive_id` int DEFAULT NULL,
  `send_id` int DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `content` text,
  `title` text,
  PRIMARY KEY (`id`),
  KEY `FKe97kyrray9crtvve70nnn2f0t` (`receive_id`),
  KEY `FK3ugqbmwby6f831gko4wqjhxbq` (`send_id`),
  CONSTRAINT `FK3ugqbmwby6f831gko4wqjhxbq` FOREIGN KEY (`send_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FKe97kyrray9crtvve70nnn2f0t` FOREIGN KEY (`receive_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `letter`
--

LOCK TABLES `letter` WRITE;
/*!40000 ALTER TABLE `letter` DISABLE KEYS */;
INSERT INTO `letter` VALUES (46,77,83,'2024-08-13 02:43:13.040677','2024-08-13 02:43:13.040677','수학 좀 알려주세요\n알고리즘 너무 어렵다멍','수학 잘 하시나멍?'),(47,81,83,'2024-08-13 02:43:44.064368','2024-08-13 02:43:44.064368','안녕 ?','케로피야'),(48,87,89,'2024-08-13 03:01:20.542925','2024-08-13 03:01:20.542925','영어랑 코딩이랑 뭔 상관인가요 ?','영어?'),(49,76,91,'2024-08-13 05:03:20.509053','2024-08-13 05:03:20.509053','바보네','바보'),(50,82,89,'2024-08-13 06:40:22.841259','2024-08-13 06:40:22.841259','푸바오 사랑해','안녕하세요'),(51,76,94,'2024-08-15 08:15:34.317698','2024-08-15 08:15:34.317698','안녕하세요','안녕하세ㅛ');
/*!40000 ALTER TABLE `letter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:05
