-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `challenge_detail`
--

DROP TABLE IF EXISTS `challenge_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenge_detail` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `challenge_id` bigint DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK54ncinof1a2leqr63isb6rkiw` (`challenge_id`),
  KEY `FKlntb0vsb92uobbqcon3tnhxci` (`member_id`),
  CONSTRAINT `FK54ncinof1a2leqr63isb6rkiw` FOREIGN KEY (`challenge_id`) REFERENCES `challenge` (`id`),
  CONSTRAINT `FKlntb0vsb92uobbqcon3tnhxci` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenge_detail`
--

LOCK TABLES `challenge_detail` WRITE;
/*!40000 ALTER TABLE `challenge_detail` DISABLE KEYS */;
INSERT INTO `challenge_detail` VALUES (24,'2024-08-13 04:59:06.792569','2024-08-13 08:16:50.284356','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/932b1aff-8dc9-4f7d-843c-e3db24ba6269_%25ED%2595%2598%25EB%258A%2598%25EC%2582%25AC%25EC%25A7%25845.jpg',162,91),(25,'2024-08-13 04:59:21.396901','2024-08-13 08:08:05.577232','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/12db741d-67d3-45b7-b4e4-ee260167dc83_%25ED%2595%2598%25EB%258A%2598%25EC%2582%25AC%25EC%25A7%25843.jpg',162,81),(26,'2024-08-13 08:06:20.625468','2024-08-14 03:03:29.129163','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/f9412087-7c1e-4280-8e2d-65ea015c2300_%25ED%2595%2598%25EB%258A%2598%2B%25EC%2582%25AC%25EC%25A7%25847.jpg',162,78),(27,'2024-08-13 08:08:56.192042','2024-08-14 03:08:26.482742','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/e9e03ba8-1497-41e6-b1cc-059cbb338e86_IMG_6326%2B%25281%2529.jpg',162,90),(28,'2024-08-13 08:10:12.351228','2024-08-14 03:07:36.790174','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/142dbd3c-68d5-4ea2-a31a-d4663ba9987a_IMG_8449%2B%25282%2529.jpg',162,88),(29,'2024-08-13 08:17:30.877333','2024-08-14 03:09:46.854705','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/4cca529e-40cf-4e75-9d5b-4bef124584fe_%25ED%2595%2598%25EB%258A%2598%25EC%2582%25AC%25EC%25A7%25842%2B%25281%2529.jpg',162,89),(30,'2024-08-15 06:38:29.525743','2024-08-15 06:38:29.525743','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/0fd21986-bdc1-4371-bad1-4253bd9a4607_%25EB%25B2%258C%25EB%25A0%2588%25EC%2597%25B0%25ED%259B%2584.PNG',168,81),(31,'2024-08-15 06:38:46.697655','2024-08-15 06:38:46.697655','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/156ef41d-2cc5-4254-858b-c513274f404d_%25ED%2595%259C%25EA%25B5%2590%25EB%258F%2599.png',165,81),(32,'2024-08-15 06:41:13.229569','2024-08-15 06:41:13.229569','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/c0e6e7c1-d12b-47a6-be56-208c66ef79ac_cat%2B%25281%2529.jpg',164,81),(33,'2024-08-15 06:43:11.086669','2024-08-15 06:43:11.086669','https://sayif-challenge.s3.ap-northeast-2.amazonaws.com/7550a21f-6004-4d57-96d9-6353fc2fc264_dog.jpg',164,90);
/*!40000 ALTER TABLE `challenge_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:07
