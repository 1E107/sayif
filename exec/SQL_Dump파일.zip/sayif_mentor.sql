-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mentor`
--

DROP TABLE IF EXISTS `mentor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mentor` (
  `mentor_id` int NOT NULL,
  `reg_code` int NOT NULL,
  `seq` int NOT NULL,
  `major` varchar(20) DEFAULT NULL,
  `intro` text,
  `track` enum('Data','Embedded','Mobile','Robot','Web') DEFAULT NULL,
  PRIMARY KEY (`mentor_id`),
  CONSTRAINT `FKaib9eox7711nqrj6dgvi3gwiw` FOREIGN KEY (`mentor_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mentor`
--

LOCK TABLES `mentor` WRITE;
/*!40000 ALTER TABLE `mentor` DISABLE KEYS */;
INSERT INTO `mentor` VALUES (76,101,11,'컴퓨터공학과','반가워요!\n마법의 소라고둥에게 무엇이든 물어보세요.','Web'),(77,101,11,'응용수학과','안녕하세요. 부산에서 수학을 전공하였고,\nSSAFY를 통해 개발 공부를 했습니다. \n함께 좋은 추억 쌓아봐요 !!','Web'),(78,101,11,'무역학부','\"코딩”이 어렵게 느껴지신다구요?\n비전공자의 실제 경험에서 나온 \n쉽게 코딩을 배우는 방법을 알려드릴게요!','Mobile'),(79,101,11,'컴퓨터공학과','백엔드, 프론트엔드 어떤 분야든\n친절히 알려드리겠습니다.\n이외의 고민 상담, 진로 상담도 얼마든 해주세요 ','Web'),(80,103,9,'수학과','저도 비전공 출신입니다.\n저와 함께 IT의 늪으로 빠져보지 않으시겠어요?','Embedded'),(81,105,10,'컴퓨터공학과','케로케로케로피 노래를 한다\n즐겁게 IT 멘토링 해볼케로피','Robot'),(82,102,10,'통계학과','안녕하세요 ! \nSSAFY에서 Mobile 트랙을 수료했습니다. \n모르는 부분 얼마든지 물어보세요 !','Mobile'),(83,102,9,'정보컴퓨터공학과','친절하고 인내심 많은 멘토와 함께하는 코딩 여행,\n학습 중에 어려움을 느끼실 때도 \n함께 극복하며 끝까지 함께합니다.','Robot'),(84,102,10,'빅데이터 융합 전공','안녕하세요. 전공으로 빅데이터를 했습니다, SSAFY에서도 Data트랙을 전공했어요. 데이터를 활용한 재미있는 활동들을 함께해요 !!','Data'),(85,103,11,'컴퓨터공학과','안녕하세요! 멘토링 기간 동안 잘 지내봐요 :) 열심히 하겠습니당 잘 부탁드려요~~','Data'),(86,104,10,'기계공학과','안녕하세요 ! 코딩애플입니다.\n저는 과일중에 사과를 제일 좋아합니다. 함께 즐거운 멘토링 해봐요 !','Embedded'),(87,105,10,'영어영문학과','코딩은 영어로 하는 겁니다. 열심히 함께 해보아요','Mobile'),(93,103,11,'컴퓨터공학과','모두 반가워요 ㅎㅎ\n소통하며 함께 실력을 끌어 올려봐요 !!\n','Web'),(96,101,10,'전자공학과','i love java','Data');
/*!40000 ALTER TABLE `mentor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:02
