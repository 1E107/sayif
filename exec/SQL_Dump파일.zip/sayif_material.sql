-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `material`
--

DROP TABLE IF EXISTS `material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material` (
  `chapter` int DEFAULT NULL,
  `hit` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `team_id` int DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKskstmai5ddy59n8lyeem700oq` (`team_id`),
  CONSTRAINT `FKskstmai5ddy59n8lyeem700oq` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material`
--

LOCK TABLES `material` WRITE;
/*!40000 ALTER TABLE `material` DISABLE KEYS */;
INSERT INTO `material` VALUES (1,0,12,30,'2024-08-13 08:06:50.000000','2024-08-13 08:06:50.000000','프로그램의 목표와 진행 방식, 아이스 브레이킹 게임 등을 통해 참여자들 간의 친밀도를 높이는 시간을 가지며, 향후 활동에 대한 기대와 목표를 공유하는 세션.','프로그램_소개_및_목적.pdf','프로그램 소개 및 목적'),(2,0,13,30,'2024-08-13 08:06:50.000000','2024-08-13 08:06:50.000000','HTML과 CSS를 이용한 웹 페이지의 기초 구조를 이해하고, 간단한 웹 페이지를 제작하며 웹 디자인의 기본 개념을 학습하는 시간.','웹_페이지_기초_이해.pdf','웹 페이지 기초 이해'),(3,0,14,30,'2024-08-13 08:06:50.000000','2024-08-13 08:06:50.000000','컴퓨터와 인터넷의 기본 개념, 하드웨어와 소프트웨어의 차이점을 설명하고, IT 지식을 쌓고 협력과 토론을 할 수 있는 기회를 제공하는 세션.','컴퓨터_및_인터넷_기초.pdf','컴퓨터 및 인터넷 기초'),(4,0,15,30,'2024-08-13 08:06:50.000000','2024-08-13 08:06:50.000000','Python 또는 Java를 이용해 기본적인 프로그래밍 언어의 문법을 이해하고, 간단한 코드를 작성해보는 실습 중심의 학습.','프로그래밍_언어_기초.pdf','프로그래밍 언어 기초'),(5,0,16,30,'2024-08-13 08:06:50.000000','2024-08-13 08:06:50.000000','스크래치와 같은 블록 코딩 도구를 사용해, 직접 간단한 애니메이션을 만들고, 협력 프로젝트를 통해 피드백을 주고받으며 창의력을 발휘하는 활동.','블록_코딩_및_애니메이션.pdf','블록 코딩 및 애니메이션'),(6,0,17,30,'2024-08-13 08:06:50.000000','2024-08-13 08:06:50.000000','퍼즐과 논리 게임을 통해 컴퓨터 프로그래밍의 기본적인 문제 해결 방법을 배우고, 창의적인 문제 해결 능력을 기르는 세션.','퍼즐_및_논리_게임.pdf','퍼즐 및 논리 게임'),(7,0,18,30,'2024-08-13 08:06:50.000000','2024-08-13 08:06:50.000000','Chat GPT의 기본적인 사용법을 익히고, 다양한 예제를 통해 활용하는 방법을 배우며, Chat GPT를 실생활에서 어떻게 유용하게 사용할 수 있는지 학습.','Chat_GPT_활용.pdf','Chat GPT 활용'),(8,0,19,30,'2024-08-13 08:06:50.000000','2024-08-13 08:06:50.000000','참가자들이 프로그램의 성과를 공유하고, 성취감을 느낄 수 있는 발표 시간. 수료증 수여 및 네트워킹 시간도 포함.','프로그램_성과_공유_및_수료식.pdf','프로그램 성과 공유 및 수료식');
/*!40000 ALTER TABLE `material` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:06
