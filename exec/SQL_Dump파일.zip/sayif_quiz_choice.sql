-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: i11e107.p.ssafy.io    Database: sayif
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quiz_choice`
--

DROP TABLE IF EXISTS `quiz_choice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_choice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `is_answer` bit(1) DEFAULT NULL,
  `quiz_id` int DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKcot8rd2jeicgpqhvtqxgotfjp` (`quiz_id`),
  CONSTRAINT `FKcot8rd2jeicgpqhvtqxgotfjp` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_choice`
--

LOCK TABLES `quiz_choice` WRITE;
/*!40000 ALTER TABLE `quiz_choice` DISABLE KEYS */;
INSERT INTO `quiz_choice` VALUES (3,_binary '\0',2,'데이터 처리 속도 최대화'),(4,_binary '',2,'데이터 중복 최소화'),(5,_binary '\0',3,'switch'),(6,_binary '\0',1,'하드웨어 성능을 향상시키는 기능'),(7,_binary '',1,'프로세스 관리, 메모리 관리, 파일 시스템 관리, 장치 관리'),(8,_binary '\0',1,'네트워크 속도를 증가시키는 기능'),(9,_binary '\0',1,'사용자 인터페이스 디자인'),(10,_binary '',6,'프로세스는 실행 중인 프로그램이며, 스레드는 프로세스 내의 실행 단위'),(11,_binary '\0',6,'스레드는 하드웨어 자원이며, 프로세스는 소프트웨어 자원'),(12,_binary '\0',6,'프로세스는 메모리를 사용하지 않으며, 스레드는 메모리를 사용한다'),(13,_binary '\0',6,'프로세스는 여러 개의 스레드를 가질 수 없다'),(14,_binary '\0',7,'하드웨어 성능을 향상시키는 기능'),(15,_binary '',7,'프로세스 관리, 메모리 관리, 파일 시스템 관리, 장치 관리'),(16,_binary '\0',7,'네트워크 속도를 증가시키는 기능'),(17,_binary '\0',7,'사용자 인터페이스 디자인'),(18,_binary '\0',2,'데이터베이스 크기 최대화'),(19,_binary '\0',2,'데이터 무결성 감소'),(20,_binary '\0',3,'for'),(21,_binary '',3,'if'),(22,_binary '\0',3,'while'),(23,_binary '\0',4,'상속 (Inheritance)'),(24,_binary '',4,'스레딩 (Threading)'),(25,_binary '\0',4,'다형성 (Polymorphism)'),(26,_binary '\0',4,'캡슐화 (Encapsulation)'),(27,_binary '\0',5,'데이터의 물리적 전송'),(28,_binary '',5,'신뢰성 있는 데이터 전송'),(29,_binary '\0',5,'네트워크 간의 경로 설정'),(30,_binary '\0',5,'애플리케이션 간의 데이터 교환'),(31,_binary '\0',8,'FTP'),(32,_binary '\0',8,'IP'),(33,_binary '',8,'HTTP'),(34,_binary '\0',8,'SSH'),(35,_binary '\0',8,'배열 (Array)'),(36,_binary '\0',8,'스택 (Stack)'),(37,_binary '\0',8,'큐 (Queue)'),(38,_binary '',8,'그래프 (Graph)'),(39,_binary '\0',10,'ALU (Arithmetic Logic Unit)'),(40,_binary '\0',10,'레지스터 (Register)'),(41,_binary '',10,'하드 디스크 (Hard Disk)'),(42,_binary '\0',10,'제어 장치 (Control Unit)'),(43,_binary '\0',11,'컴파일러가 자동으로 타입을 할당해주기 때문에'),(44,_binary '',11,'파이썬은 동적 타입 언어이기 때문에'),(45,_binary '\0',11,'파이썬은 정적 타입 언어이기 때문에'),(46,_binary '\0',11,'변수 타입 선언이 필수가 아니기 때문에'),(47,_binary '\0',12,'16비트'),(48,_binary '',12,'32비트'),(49,_binary '\0',12,'64비트'),(50,_binary '\0',12,'128비트'),(51,_binary '\0',13,'팩토리얼 (Factorial)'),(52,_binary '\0',13,'피보나치 수열 (Fibonacci Sequence)'),(53,_binary '\0',13,'이진 탐색 (Binary Search)'),(54,_binary '',13,'힙 정렬 (Heap Sort)'),(55,_binary '\0',14,'INSERT'),(56,_binary '\0',14,'DELETE'),(57,_binary '\0',14,'UPDATE'),(58,_binary '',14,'SELECT'),(59,_binary '\0',15,'프로세스 관리'),(60,_binary '\0',15,'메모리 관리'),(61,_binary '',15,'사용자 인터페이스 디자인'),(62,_binary '\0',15,'파일 시스템 관리'),(63,_binary '\0',16,'캡슐화 (Encapsulation)'),(64,_binary '\0',16,'상속 (Inheritance)'),(65,_binary '\0',16,'다형성 (Polymorphism)'),(66,_binary '',16,'병렬 처리 (Parallel Processing)'),(67,_binary '\0',17,'요청이 성공적으로 처리됨'),(68,_binary '',17,'리소스를 찾을 수 없음'),(69,_binary '\0',17,'서버 오류 발생'),(70,_binary '\0',17,'요청이 허용되지 않음'),(71,_binary '\0',18,'사람과의 대화를 통해 실시간으로 학습'),(72,_binary '',18,'대규모의 텍스트 데이터를 바탕으로 사전 학습'),(73,_binary '\0',18,'웹에서 실시간으로 데이터를 수집하여 학습'),(74,_binary '\0',18,'특정 도메인의 지식을 통해 한정적으로 학습'),(75,_binary '\0',19,'네, 모든 질문에 대해 정확한 답변을 제공합니다.'),(76,_binary '',19,'아니요, ChatGPT는 종종 틀리거나 부정확한 답변을 할 수 있습니다.'),(77,_binary '\0',19,'네, 하지만 단순한 질문에만 해당됩니다.'),(78,_binary '\0',19,'아니요, 하지만 항상 가장 최신의 정보만을 제공합니다.'),(79,_binary '\0',20,'특정 언어만을 이해하고 처리할 수 있다.'),(80,_binary '\0',20,'인간의 감정을 이해하고 공감할 수 있다.'),(81,_binary '',20,'여러 언어로 대화를 할 수 있으며, 다양한 주제에 대해 답변할 수 있다.'),(82,_binary '\0',20,'사용자의 생각을 읽고 이에 맞춰 답변을 작성한다.'),(83,_binary '',21,'TCP는 연결 지향적 프로토콜이며, UDP는 비연결 지향적 프로토콜이다.'),(84,_binary '\0',21,'TCP는 신뢰할 수 없고, UDP는 신뢰할 수 있다.'),(85,_binary '\0',21,'TCP는 데이터를 암호화하고, UDP는 데이터를 암호화하지 않는다.'),(86,_binary '\0',21,'TCP는 패킷을 순서대로 전달하지 않으며, UDP는 패킷을 순서대로 전달한다.'),(87,_binary '',22,'프로세스의 메모리 공간을 고정된 크기로 분할하여 할당한다'),(88,_binary '\0',22,'메모리 할당 시 프로세스의 크기에 따라 메모리 블록 크기를 동적으로 조정한다.'),(89,_binary '\0',22,'프로세스의 메모리 공간을 가변 크기의 세그먼트로 분할하여 할당한다.'),(90,_binary '\0',22,'프로세스의 메모리 할당을 FIFO 방식으로 관리한다.'),(91,_binary '\0',23,'함수가 호출될 때마다 새로운 리스트 객체가 생성되기 때문이다.'),(92,_binary '',23,'기본 인자는 함수가 정의될 때 한 번만 평가되고, 그 후로는 해당 인스턴스를 계속 사용하기 때문이다.'),(93,_binary '\0',23,'함수 호출이 끝날 때마다 모든 인자들이 초기화되기 때문이다.'),(94,_binary '\0',23,'파이썬에서 리스트는 기본적으로 불변 객체이기 때문이다.'),(95,_binary '\0',24,'<div> 태그를 사용하여 요소를 블록 단위로 나눈다.'),(96,_binary '',24,'float 속성을 사용하여 요소를 왼쪽이나 오른쪽으로 배치한다.'),(97,_binary '\0',24,'padding 속성을 사용하여 요소 간의 간격을 조정한다.'),(98,_binary '\0',24,'text-align 속성을 사용하여 요소를 중앙에 배치한다.'),(99,_binary '',25,'복잡한 코드를 직접 작성할 필요 없이, 시각적으로 명령어를 구성할 수 있다.'),(100,_binary '\0',25,'모든 프로그래밍 언어를 지원한다.'),(101,_binary '\0',25,'코드 작성 시 오류를 전혀 발생시키지 않는다.'),(102,_binary '\0',25,'사용자가 컴파일러를 직접 설정해야 한다.'),(103,_binary '\0',26,'프로그래밍 전문가'),(104,_binary '\0',26,'컴퓨터 과학 연구원'),(105,_binary '',26,'프로그래밍을 처음 배우는 초보자나 어린이'),(106,_binary '\0',26,'게임 개발자'),(107,_binary '\0',27,'반복 작업을 수행하도록 한다.'),(108,_binary '',27,'특정 조건에 따라 서로 다른 명령을 실행하도록 한다.'),(109,_binary '\0',27,'변수의 값을 저장하고 관리한다.'),(110,_binary '\0',27,'블록의 모양과 색상을 변경한다.');
/*!40000 ALTER TABLE `quiz_choice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  8:52:09
